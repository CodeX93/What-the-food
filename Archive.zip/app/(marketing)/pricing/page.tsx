import type { Metadata } from "next";
import PricingPage from "@/views/Pricing";
import { getPreviewImageUrlFromRequest, getRequestUrl, getCanonicalUrlFromRequest } from "@/lib/seo/siteUrl";

export async function generateMetadata(): Promise<Metadata> {
  const requestUrl = await getRequestUrl();
  const imageUrl = getPreviewImageUrlFromRequest("Pricing.png", requestUrl);
  const canonicalUrl = await getCanonicalUrlFromRequest('/pricing');

  const title = "What The Food Pricing & Packages | View Plans";
  const description =
    "Compare our freemium plans to see how far personalized health context and account analytics can take you. Get started now for free - No signups required.";

  return {
    title,
    description,
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title,
      description,
      url: canonicalUrl,
      type: "website",
      images: [imageUrl],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [imageUrl],
    },
};
}

export default function PricingRoute() {
  return (
    <>
      {/* H1 for SEO - always visible to crawlers */}
      <h1 className="sr-only">What The Food Pricing & Packages</h1>
      <PricingPage />
    </>
  );
}

