// integrations/supabase/client.ts

"use client";

import { createBrowserClient } from '@supabase/ssr';
import type { Database } from './types';

export const supabase = createBrowserClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// For backwards compatibility if you're importing it elsewhere
export const createClient = () => supabase;