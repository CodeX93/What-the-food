'use client';

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  User as UserIcon,
  Mail,
  Calendar,
  Save,
  Camera,
  CheckCircle2,
  Crown,
  CreditCard,
  ArrowRight,
  Code,
  Users,
  Scale,
  Ruler,
  AlertCircle,
  CheckCircle,
  Target,
  Activity,
} from "lucide-react";
import { getPlatformSubscription } from "@/utils/subscription";
import type { User } from "@supabase/supabase-js";
import { calculateBMI, getBMICategory, getIdealWeightRange } from "@/utils/bmi";

export type ProfileClientProps = {
  initialUser?: User | null;
  initialProfile?: any;
  initialSubscription?: any;
  initialPlanName?: string | null;
};

export function ProfileClient({
  initialUser = null,
  initialProfile = null,
  initialSubscription = null,
  initialPlanName = null,
}: ProfileClientProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(initialUser);
  const [profile, setProfile] = useState<any>(initialProfile);
  const [loading, setLoading] = useState(!initialUser);
  const [subscription, setSubscription] = useState<any>(initialSubscription);
  const [saving, setSaving] = useState(false);
  const [planName, setPlanName] = useState<string | null>(initialPlanName);
  const [email, setEmail] = useState(initialUser?.email || "");
  const [userInitials, setUserInitials] = useState(
    initialUser?.email ? initialUser.email.split("@")[0].substring(0, 2).toUpperCase() : "U"
  );
  const [gender, setGender] = useState<string>(initialProfile?.gender || "");
  const [age, setAge] = useState<string>(initialProfile?.age?.toString() || "");
  const [weight, setWeight] = useState<string>(initialProfile?.weight_kg?.toString() || "");
  const [height, setHeight] = useState<string>(initialProfile?.height_cm?.toString() || "");
  const [goal, setGoal] = useState<string>(initialProfile?.goal || "");
  const [activityLevel, setActivityLevel] = useState<string>(initialProfile?.activity_level || "");
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (initialUser) {
      setUser(initialUser);
      setEmail(initialUser.email || "");
      setUserInitials(
        initialUser.email ? initialUser.email.split("@")[0].substring(0, 2).toUpperCase() : "U"
      );
      setLoading(false);
    }
  }, [initialUser]);

  useEffect(() => {
    setProfile(initialProfile);
    if (initialProfile) {
      setGender(initialProfile.gender || "");
      setAge(initialProfile.age?.toString() || "");
      setWeight(initialProfile.weight_kg?.toString() || "");
      setHeight(initialProfile.height_cm?.toString() || "");
      setGoal(initialProfile.goal || "");
      setActivityLevel(initialProfile.activity_level || "");
    }
  }, [initialProfile]);

  useEffect(() => {
    setSubscription(initialSubscription);
    // Clear plan name if subscription is free
    if (initialSubscription?.subscription_type === "free") {
      setPlanName(null);
    }
  }, [initialSubscription]);

  useEffect(() => {
    setPlanName(initialPlanName ?? null);
  }, [initialPlanName]);

  useEffect(() => {
    if (initialUser) {
      return;
    }

    let cancelled = false;

    const fetchUserData = async () => {
      try {
        setLoading(true);
        const {
          data: { session },
          error,
        } = await supabase.auth.getSession();

        if (error || !session?.user) {
          router.push("/auth");
          return;
        }

        if (cancelled) return;

        setUser(session.user);
        setEmail(session.user.email || "");
        setUserInitials(
          session.user.email ? session.user.email.split("@")[0].substring(0, 2).toUpperCase() : "U"
        );
console.log("hello world");
        const { data: profileData } = await (supabase as any)
          .from("profiles")
          .select("*")
          .eq("id", session.user.id)
          .maybeSingle();
        if (!cancelled && profileData) {
          setProfile(profileData);
          setGender(profileData.gender || "");
          setAge(profileData.age?.toString() || "");
          setWeight(profileData.weight_kg?.toString() || "");
          setHeight(profileData.height_cm?.toString() || "");
          setGoal(profileData.goal || "");
          setActivityLevel(profileData.activity_level || "");
        }

        const sub = await getPlatformSubscription(session.user.id);
        if (!cancelled) {
          setSubscription(sub);

          // Only fetch plan name if subscription is premium and has platform_plan_id
          if (sub?.subscription_type === "premium" && sub?.platform_plan_id) {
            const { data: planRow } = await (supabase as any)
              .from("platform_plans")
              .select("name")
              .eq("id", sub.platform_plan_id)
              .maybeSingle();
            if (!cancelled && planRow?.name) {
              setPlanName(planRow.name);
            } else {
              setPlanName(null);
            }
          } else {
            // Clear plan name if subscription is free
            setPlanName(null);
          }
        }

      } catch (err) {
        console.error("Error fetching user data:", err);
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void fetchUserData();

    return () => {
      cancelled = true;
    };
  }, [initialUser, router]);

  const handleSave = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session?.user) {
        router.push("/auth");
        return;
      }

      const form = formRef.current || (event.currentTarget as HTMLFormElement);
      const formData = new FormData(form);
      const fullNameRaw = (formData.get("full_name") as string) ?? "";

      const fullName = fullNameRaw.trim() || null;
      
      // Parse demographic fields
      const genderValue = gender.trim() || null;
      const ageValue = age.trim() ? parseInt(age.trim(), 10) : null;
      const weightValue = weight.trim() ? parseFloat(weight.trim()) : null;
      const heightValue = height.trim() ? parseInt(height.trim(), 10) : null;
      const goalValue = goal.trim() || null;
      const activityLevelValue = activityLevel.trim() || null;

      const { error: updateError } = await (supabase as any)
        .from("profiles")
        .update({
          full_name: fullName,
          gender: genderValue,
          age: ageValue,
          weight_kg: weightValue,
          height_cm: heightValue,
          goal: goalValue,
          activity_level: activityLevelValue,
          updated_at: new Date().toISOString(),
        })
        .eq("id", session.user.id);

      if (updateError) {
        throw updateError;
      }

      const { data: updatedProfile, error: fetchError } = await (supabase as any)
        .from("profiles")
        .select("*")
        .eq("id", session.user.id)
        .maybeSingle();

      if (!fetchError && updatedProfile) {
        setProfile(updatedProfile);
        // Update state variables to reflect saved values
        setGender(updatedProfile.gender || "");
        setAge(updatedProfile.age?.toString() || "");
        setWeight(updatedProfile.weight_kg?.toString() || "");
        setHeight(updatedProfile.height_cm?.toString() || "");
        setGoal(updatedProfile.goal || "");
        setActivityLevel(updatedProfile.activity_level || "");
      }

      // Check if profile is now complete
      const isNowComplete = updatedProfile && 
        updatedProfile.full_name &&
        updatedProfile.gender &&
        updatedProfile.age !== null &&
        updatedProfile.weight_kg !== null &&
        updatedProfile.height_cm !== null &&
        updatedProfile.goal &&
        updatedProfile.activity_level;

      toast({
        title: "Success",
        description: isNowComplete 
          ? "Profile updated and completed! 🎉"
          : "Profile updated successfully.",
      });
    } catch (error: any) {
      console.error("Error saving profile:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <main className="flex-1 flex items-center justify-center py-20 bg-gradient-to-b from-background to-muted/20">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-primary/20 border-t-primary" />
            <div className="absolute inset-0 flex items-center justify-center">
              <UserIcon className="h-6 w-6 text-primary animate-pulse" />
            </div>
          </div>
          <p className="text-muted-foreground animate-pulse">Loading your profile...</p>
        </div>
      </main>
    );
  }

  const isPremium = subscription?.subscription_type === "premium";

  // Calculate BMI
  const currentBMI = calculateBMI(profile?.weight_kg, profile?.height_cm);
  const bmiCategory = getBMICategory(currentBMI);
  const idealWeightRange = getIdealWeightRange(profile?.height_cm);

  // Calculate profile completion
  const profileFields = [
    { key: 'full_name', value: profile?.full_name },
    { key: 'gender', value: profile?.gender },
    { key: 'age', value: profile?.age },
    { key: 'weight_kg', value: profile?.weight_kg },
    { key: 'height_cm', value: profile?.height_cm },
    { key: 'goal', value: profile?.goal },
    { key: 'activity_level', value: profile?.activity_level },
  ];
  
  const completedFields = profileFields.filter(field => {
    if (field.key === 'age' || field.key === 'weight_kg' || field.key === 'height_cm') {
      return field.value !== null && field.value !== undefined && field.value !== '';
    }
    return field.value && field.value.toString().trim() !== '';
  }).length;
  
  const totalFields = profileFields.length;
  const completionPercentage = Math.round((completedFields / totalFields) * 100);
  const isProfileComplete = completedFields === totalFields;
  const missingFields = profileFields
    .filter(field => {
      if (field.key === 'age' || field.key === 'weight_kg' || field.key === 'height_cm') {
        return field.value === null || field.value === undefined || field.value === '';
      }
      return !field.value || field.value.toString().trim() === '';
    })
    .map(field => {
      const labels: Record<string, string> = {
        full_name: 'Full Name',
        gender: 'Gender',
        age: 'Age',
        weight_kg: 'Weight',
        height_cm: 'Height',
      };
      return labels[field.key];
    });

  return (
    <main className="flex-1">
      <div className="container mx-auto px-4 py-8 sm:py-12 w-full">
        {!isProfileComplete && (
          <Card className="mb-6 border-2 border-primary/20 bg-gradient-to-br from-primary/5 via-primary/10 to-primary/5 shadow-lg">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className="p-2 rounded-lg bg-primary/20">
                    <AlertCircle className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-1">Complete Your Profile</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {missingFields.length > 0 
                        ? `Please add your ${missingFields.join(', ').toLowerCase()} to get personalized insights.`
                        : 'Your profile is almost complete!'}
                    </p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Profile Completion</span>
                        <span className="font-semibold text-primary">{completionPercentage}%</span>
                      </div>
                      <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-primary to-primary/80 transition-all duration-500 rounded-full"
                          style={{ width: `${completionPercentage}%` }}
                        />
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {profileFields.map((field) => {
                          const isCompleted = field.key === 'age' || field.key === 'weight_kg' || field.key === 'height_cm'
                            ? field.value !== null && field.value !== undefined && field.value !== ''
                            : field.value && field.value.toString().trim() !== '';
                          const labels: Record<string, string> = {
                            full_name: 'Full Name',
                            gender: 'Gender',
                            age: 'Age',
                            weight_kg: 'Weight',
                            height_cm: 'Height',
                            goal: 'Goal',
                            activity_level: 'Activity Level',
                          };
                          return (
                            <div
                              key={field.key}
                              className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full ${
                                isCompleted
                                  ? 'bg-primary/20 text-primary border border-primary/30'
                                  : 'bg-muted text-muted-foreground border border-muted'
                              }`}
                            >
                              {isCompleted ? (
                                <CheckCircle className="h-3 w-3" />
                              ) : (
                                <AlertCircle className="h-3 w-3" />
                              )}
                              <span>{labels[field.key]}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="mb-8 sm:mb-12">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-2 bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent pb-2">
                Profile Settings
              </h1>
              <p className="text-muted-foreground text-sm sm:text-base">
                Manage your account information and subscriptions
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {isPremium && (
                <Badge variant="secondary" className="px-4 py-2 text-sm shadow-md">
                  <Crown className="h-4 w-4 mr-2" /> Premium
                </Badge>
              )}
            </div>
          </div>
        </div>

        <Card className="mb-8 shadow-xl border-2 border-primary/10 bg-gradient-to-br from-card via-card to-card/50">
          <CardHeader className="pb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10">
                <UserIcon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle className="text-2xl sm:text-3xl">Profile Information</CardTitle>
                <CardDescription className="mt-1 text-base">Update your personal information</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <form ref={formRef} onSubmit={handleSave} className="space-y-6">
              <div className="flex flex-col items-center sm:flex-row gap-8 pb-8 border-b-2 border-dashed">
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary to-secondary rounded-full blur-xl opacity-30 group-hover:opacity-50 transition-opacity" />
                  <Avatar className="relative h-32 w-32 sm:h-40 sm:w-40 border-4 border-primary/30 shadow-2xl ring-4 ring-primary/10 transition-all">
                    <AvatarImage src={profile?.avatar_url} className="object-cover" />
                    <AvatarFallback className="text-4xl sm:text-5xl bg-gradient-to-br from-primary via-primary to-secondary text-primary-foreground font-bold">
                      {userInitials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center cursor-pointer backdrop-blur-sm">
                    <div className="bg-white/20 backdrop-blur-md rounded-full p-3">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                  </div>
                </div>
                <div className="text-center sm:text-left flex-1 space-y-3">
                  <div>
                    <h3 className="font-bold text-2xl mb-1">{profile?.full_name || "Your Name"}</h3>
                    <p className="text-muted-foreground flex items-center justify-center sm:justify-start gap-2">
                      <Mail className="h-4 w-4" /> {email}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      toast({
                        title: "Coming Soon",
                        description: "Avatar upload feature will be available soon.",
                      })
                    }
                  >
                    <Camera className="h-3 w-3 mr-2" /> Change Photo
                  </Button>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="email" className="text-sm font-semibold flex items-center gap-2">
                    <Mail className="h-4 w-4 text-primary" /> Email Address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="email" type="email" value={email} disabled className="pl-12 h-12 bg-muted/50 border-2" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1.5">Email cannot be changed</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="full_name" className="text-sm font-semibold flex items-center gap-2">
                    <UserIcon className="h-4 w-4 text-primary" /> Full Name
                  </Label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="full_name"
                      name="full_name"
                      type="text"
                      defaultValue={profile?.full_name || ""}
                      placeholder="Enter your full name"
                      className="pl-12 h-12 border-2"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gender" className="text-sm font-semibold flex items-center gap-2">
                    <Users className="h-4 w-4 text-primary" /> Gender
                  </Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger className="h-12 border-2">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age" className="text-sm font-semibold flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-primary" /> Age
                  </Label>
                  <div className="relative">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="age"
                      type="number"
                      min="0"
                      max="150"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="Enter your age"
                      className="pl-12 h-12 border-2"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weight" className="text-sm font-semibold flex items-center gap-2">
                    <Scale className="h-4 w-4 text-primary" /> Weight (kg)
                  </Label>
                  <div className="relative">
                    <Scale className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="weight"
                      type="number"
                      min="0"
                      step="0.1"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      placeholder="Enter weight in kg"
                      className="pl-12 h-12 border-2"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="height" className="text-sm font-semibold flex items-center gap-2">
                    <Ruler className="h-4 w-4 text-primary" /> Height (cm)
                  </Label>
                  <div className="relative">
                    <Ruler className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="height"
                      type="number"
                      min="0"
                      max="300"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      placeholder="Enter height in cm"
                      className="pl-12 h-12 border-2"
                    />
                  </div>
                </div>

                {/* BMI Display */}
                {currentBMI && (
                  <div className="sm:col-span-2 p-4 rounded-xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-2 border-primary/20">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1 font-medium">Body Mass Index</p>
                        <p className="text-2xl font-bold text-foreground">{currentBMI}</p>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={`text-sm px-3 py-1 ${
                          bmiCategory.color === "green" ? "border-green-500 text-green-700 bg-green-50" :
                          bmiCategory.color === "blue" ? "border-blue-500 text-blue-700 bg-blue-50" :
                          bmiCategory.color === "orange" ? "border-orange-500 text-orange-700 bg-orange-50" :
                          "border-red-500 text-red-700 bg-red-50"
                        }`}
                      >
                        {bmiCategory.category}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{bmiCategory.description}</p>
                    {idealWeightRange && (
                      <p className="text-xs text-muted-foreground">
                        Ideal weight range: {idealWeightRange.min} - {idealWeightRange.max} kg
                      </p>
                    )}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="goal" className="text-sm font-semibold flex items-center gap-2">
                    <Target className="h-4 w-4 text-primary" /> Health Goal
                  </Label>
                  <Select value={goal} onValueChange={setGoal}>
                    <SelectTrigger className="h-12 border-2">
                      <SelectValue placeholder="Select your goal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weight_loss">Weight Loss</SelectItem>
                      <SelectItem value="weight_gain">Weight Gain</SelectItem>
                      <SelectItem value="maintain_weight">Maintain Weight</SelectItem>
                      <SelectItem value="build_muscle">Build Muscle</SelectItem>
                      <SelectItem value="improve_fitness">Improve Fitness</SelectItem>
                      <SelectItem value="general_health">General Health</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="activity_level" className="text-sm font-semibold flex items-center gap-2">
                    <Activity className="h-4 w-4 text-primary" /> Activity Level
                  </Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger className="h-12 border-2">
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                      <SelectItem value="light_active">Lightly Active (light exercise 1-3 days/week)</SelectItem>
                      <SelectItem value="moderately_active">Moderately Active (moderate exercise 3-5 days/week)</SelectItem>
                      <SelectItem value="very_active">Very Active (hard exercise 6-7 days/week)</SelectItem>
                      <SelectItem value="extremely_active">Extremely Active (very hard exercise, physical job)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-6 border-t-2">
                <Button
                  type="submit"
                  className="w-full h-12 text-base font-semibold shadow-lg"
                  disabled={saving}
                >
                  {saving ? (
                    <>
                      <Save className="mr-2 h-5 w-5 animate-spin" /> Saving Changes...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-5 w-5" /> Save Changes
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8">
          <Card className="shadow-xl border-2 border-primary/10 bg-gradient-to-br from-card via-card to-card/50">
            <CardHeader className="pb-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-xl ${isPremium ? "bg-gradient-to-br from-primary/30 to-primary/10" : "bg-muted/50"}`}>
                    <CreditCard className={`h-6 w-6 ${isPremium ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div>
                    <CardTitle className="text-xl sm:text-2xl">Platform Subscription</CardTitle>
                    <CardDescription className="mt-1">Your main app plan</CardDescription>
                  </div>
                </div>
                {isPremium && (
                  <Badge variant="default" className="shadow-md">
                    <Crown className="h-3 w-3 mr-1" /> Active
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {subscription ? (
                <div className="space-y-6">
                  <div className={`relative overflow-hidden p-5 rounded-xl border-2 ${
                    isPremium ? "bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border-primary/30" : "bg-muted/50 border-dashed"
                  }`}>
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-lg ${isPremium ? "bg-primary/20" : "bg-muted"}`}>
                        {isPremium ? (
                          <Crown className="h-6 w-6 text-primary" />
                        ) : (
                          <CheckCircle2 className="h-6 w-6 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1 font-medium">Current Plan</p>
                        <p className="font-bold text-xl capitalize">
                          {subscription.subscription_type === "premium" ? "Premium" : "Free"}
                        </p>
                      </div>
                    </div>
                  </div>

                  {planName && isPremium && (
                    <div className="p-4 rounded-xl bg-gradient-to-br from-muted/50 to-muted/30 border border-primary/10">
                      <p className="text-xs text-muted-foreground mb-2 font-medium">Plan Name</p>
                      <p className="font-bold text-lg">{planName}</p>
                    </div>
                  )}

                  {subscription.billing_cycle && (
                    <div className="p-4 rounded-xl bg-gradient-to-br from-muted/50 to-muted/30 border border-primary/10">
                      <p className="text-xs text-muted-foreground mb-2 font-medium">Billing Cycle</p>
                      <p className="font-semibold text-base capitalize flex items-center gap-2">
                        <Calendar className="h-5 w-5 text-primary" />
                        {subscription.billing_cycle}
                      </p>
                    </div>
                  )}

                  {subscription.current_period_end && (
                    <div className="p-4 rounded-xl bg-gradient-to-br from-muted/50 to-muted/30 border border-primary/10">
                      <p className="text-xs text-muted-foreground mb-2 font-medium">Next Billing Date</p>
                      <p className="font-semibold text-base">
                        {new Date(subscription.current_period_end).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12 space-y-4">
                  <div className="mx-auto w-20 h-20 rounded-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center shadow-lg">
                    <CreditCard className="h-10 w-10 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-2 font-semibold">No subscription found</p>
                    <p className="text-sm text-muted-foreground mb-6">Choose a plan to get started</p>
                  </div>
                </div>
              )}

              <div className="pt-6 border-t-2 mt-6">
                <Button
                  variant={isPremium ? "outline" : "default"}
                  className="w-full h-12 font-semibold"
                  onClick={() => router.push("/plans")}
                >
                  {isPremium ? (
                    <>
                      Change Plan <ArrowRight className="ml-2 h-5 w-5" />
                    </>
                  ) : (
                    <>
                      Upgrade Plan <Crown className="ml-2 h-5 w-5" />
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
